// Custom js

$(document).ready(function () {
    $('.slider-section').slick({
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 2,
        dots: true,
        arrows: true
    });
});